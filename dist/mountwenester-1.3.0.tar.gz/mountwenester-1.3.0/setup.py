from distutils.core import setup

setup (
	name            = 'mountwenester',
	version         = '1.3.0',
	py_modules      = ['mountwenester'],
	author          = 'mountwe',
	author_email    = 'mountwe@live.com',
	url             = 'http://umquhile.org/mw',
	description     = 'A simple printer of nested lists',
	)